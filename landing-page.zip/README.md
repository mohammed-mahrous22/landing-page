# Landing Page Project procedural & oop

## Table of Contents

* [Description](#Description)
* [Technologies used](#Technologies used)

## Description

this project is using the DOM to create a dynamic navigation bar of the sections inside the html file.

the project is written in two styles  procedural `js/app.js` and object oriented `js/new_oop_app.js` .

## Technologies used

Technologies used on this app is  `JavaScript`, `CSS`, `HTML` .


